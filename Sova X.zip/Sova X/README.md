Promises 🔥
______

50 Stars and I'll fix every error that there is

100 Stars and we will add a whole new page for even more things!
______

Features ✨
______

22 Features, 5 credits, 6 features in both All In Ones,
Best Features are Token Nukers, token managers and probably the raiding (these are fairly slow but not my problem)

![image](https://user-images.githubusercontent.com/96021763/150035189-5484e6ac-8889-40a5-a1de-75879f3d55e0.png)
______

Usage 🙌
______

Just run PackageInstaller.bat then run Raptor.py (Obviously you have to have python), note that this uses ctypes which is strictly for Windows only. 
If you are an user who is on a different OS just go through the code and delete all the lines that has ctypes as there is no module for window title 
except ones for only windows, or just use replit.
______

Credits 🤝
______

Main Coder ~ ! Aran#9999

Helped with functions ~ vivid#9541

Original Idea ~ tkn#0908

Big Thanks to all the testers that made sure this program ran smooth


All the credits can be found inside the program too. 
______

License 😈
______

Read the LICENSE that was given in the program, but if you don't want to read it here is the TLDR;

You can give this program away,
You cannot charge people to get this program,
YOU CANNOT REMOVE ANY CREDITS OR IDENTIFICATION ON ANYTHING THAT WE PUT

______

Note 📝
______

I have made this program free because why not, star this project if you like it, we are human so we cannot make everything perfect if something doesn't work
we might fix we might not, its just how it goes BY THIS I MEAN I WILL NOT MAINTAIN THIS PROJECT PROPERLY, 
and I know that it will get skidded but what can you do?
This was not obfuscated because thats sketch af so look at the src to look for any grabber or if you want to learn Api's and stuff
You can add Aran or Vivid if you encounter any bugs and we will fix it, Hope You Enjoy!

